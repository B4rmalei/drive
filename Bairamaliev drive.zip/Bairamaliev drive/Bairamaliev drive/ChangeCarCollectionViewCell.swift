//
//  ChangeCarCollectionViewCell.swift
//  Kanavichev drive
//
//  Created by Канавичев Алексей Александрович on 23/1/2023.
//

import UIKit


class ChangeCarCollectionViewCell: UICollectionViewController {
    
    @IBOutlet weak var carPicture: UIImageView!


}
